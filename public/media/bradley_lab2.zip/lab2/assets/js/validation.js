


var validation = {

validArray:[this.notEmpty,this.validAge,this.validInteger,this.validRange,this.validNumber,this.validAge],
testMethod: function(options) {
if(typeof options === "object" && !Array.isArray(options) && options !== null){
    alert("it is an object");
}
  
else {
    alert("it is an NOT object");
}
   
},
isNotEmpty: function(value,errElement){
if (value.length==0){
errElement.innerHTML="Field must not be empty";
return false;
}
else {
    errElement.innerHTML="";
    return true;
}
},
isInteger: function (value,errElement){
    if (Math.round(value) === value){
    errElement.innerHTML="Age must be an integer";
  
    return false;
    }
    else {
        
        return true;  
    }
},
isWithinRange: function (number, low, high,errElement){
 
if(number<low || number >high){
    errElement.innerHTML= number +" is out of range!";
 
    return false;
}
else {
    errElement.innerHTML=""; 
    
    return true;
}
},
isNumber: function (value,errElement){
   
    if (isNaN(value)){
        
        errElement.innerHTML= value +" is not a number!"; 
        return false; 
    }
    else if (value==""){
        errElement.innerHTML= value +"Please provide a valid number"; 
     
        return false; 
    }
    else {
        errElement.innerHTML= ""; 
       
        return true;
    }
},
checkValidation: function(errorArray){
   validCheck=true;
    for (i=0;i<errorArray.length;i++){
        if (errorArray[i]===false){
            validCheck=false;
        }
    }
    return validCheck;
}
    

};

