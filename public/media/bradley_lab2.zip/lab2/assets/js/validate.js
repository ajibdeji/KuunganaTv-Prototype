window.onload=function(){
document.getElementById('register').onclick=validate;
//document.getElementById('reset').onclick=clearAll;
}

//alert ("Test");
function validate() {
//alert ("Test");
var validated=false;
// Validation Array
var valid=[];

var emailPattern=/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

// Validate email
if (document.getElementById('email').value==="") {
document.getElementById('errEmail').innerHTML= " Please enter an email";
valid[0]=false;
}

else if (!emailPattern.test(document.getElementById('email').value)){
document.getElementById('errEmail').innerHTML= " Enter a correct Email";
valid[0]=false;
}

else {
document.getElementById('errEmail').innerHTML= "";
valid[0]=true;
}

// Name validation

var pattern=/^[a-zA-Z]{3,20}$/;

if (document.getElementById('fname').value==""){
document.getElementById('errfname').innerHTML= " Please Enter name";
valid[1]=false;
}
else if (!pattern.test(document.getElementById('fname').value)){
document.getElementById('errfname').innerHTML= " Error in name";
valid[1]=false;
}


else {
document.getElementById('errfname').innerHTML= "";
valid[1]=true;
}


//contact validation
//
//var contact = document.getElementsByName('contact');
//var contactselected =false;
//for (var i=1;i<contact.length;i++){
//  
//if(contact[i].checked){
//contactselected=true;
//break;
//}
//}
//if (!contactselected){
//document.getElementById('errContact').innerHTML= " Contact method to be selected";
//valid[2]=false;
//
//}
//else {
//document.getElementById('errContact').innerHTML= " ";
//valid[2]=true;
//
//
//}

// Options slected  Validation

if (document.getElementById('country').value ==="")
{
document.getElementById('errCountry').innerHTML= " Select a country";
valid[2]=false;
}
else {
document.getElementById('errCountry').innerHTML= " ";
valid[2]=true;
}

//Terms of service validation

if (document.getElementById('service').checked){
    document.getElementById('errCheckbox').innerHTML="";
    valid[3]=true;
    
}
else {
    document.getElementById('errCheckbox').innerHTML="Please click I accept to agree";
    valid[3]=false;
    
}

// Check if there are no errors and then do action if none.
var falseCount=0;
for (var i=0;i<valid.length;i++){

if (valid[i]===false){
falseCount++; 

}
}
//alert(valid);
if (falseCount<1){
    
    document.getElementById("reg").style.display="none";
   var printName=document.getElementById("fname").value;
    document.getElementById("thankYou").innerHTML="Thank You "+printName+
            " for submitting the form, we will contact you soon";
  

}

}



function clearAll(){
 document.getElementById('fname').innerHTML="";
 document.getElementById('email').innerHTML="";
 document.getElementById('service').checked=false;

}