<html>
<head>
<title>Form Process Page</title>

<!-- BootStrap  and styles -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css" />
<link rel="stylesheet" href="assets/css/styles.css" />

</head>
<body>
<div  class="container">
<?php include 'header.php'; ?>

<p id="response">
    Welcome <?php echo  $_POST['first-name']." ". $_POST['last-name']; ?>
</p>

<p>
Thank you for your salary information.
</p>


<?php include 'footer.php'; ?>
</div>
</body>
</html>
