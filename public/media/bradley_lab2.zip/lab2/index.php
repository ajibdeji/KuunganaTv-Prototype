<html>
<head>
<title>Bradley's page</title>

<!-- BootStrap  and styles -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css" />
<link rel="stylesheet" href="assets/css/styles.css" />

</head>
<body>
<div class="container">

<?php include 'header.php'; ?>

<form id="form-salary" method="post" action="process.php">
  <div class="form-group row">
    <label for="first-name" class="col-sm-2 col-md-2 col-lg-2 col-form-label">First Name</label>
    <div class="col-sm-10 col-md-6 col-lg-6">
      <input type="text" class="form-control" id="first-name" placeholder="First Name" name="first-name">
      <span id ="first-name-info" class="field-info">Enter your First Name only</span>
    </div>
  </div>
  <div class="form-group row">
    <label for="last-name" class="col-sm-2 col-md-2 col-lg-2 col-form-label">Last Name</label>
    <div class="col-sm-10 col-md-6 col-lg-6">
      <input type="text" class="form-control" id="last-name" placeholder="Last Name" name="last-name">
      <span id ="last-name-info" class="field-info">Enter your Last Name only</span>
    </div>
  </div>
  <div class="form-group row">
    <label for="age" class="col-sm-2 col-md-2 col-lg-2 col-form-label">Age</label>
    <div class="col-sm-10 col-md-6 col-lg-6">
      <input type="number" class="form-control" id="age" placeholder="Age" name="age">
      <span id ="age-info" class="field-info">Enter a valid age</span>
    </div>
  </div>
  <div class="form-group row">
    <label for="salary" class="col-sm-2 col-md-2 col-lg-2 col-form-label">Salary</label>
    <div class="col-sm-10 col-md-6 col-lg-6">
      <input type="text" class="form-control" id="salary" placeholder="Salary" name="salary">
      <span id ="salary-info" class="field-info">Enter the number amount of your salary</span>
    </div>
  </div>
  <div class="form-group row">
    <div class="col-sm-10 col-md-6 col-lg-6" >
      <button id="btn-salary" type="button" class="btn btn-primary">Check</button>
    </div>
  </div>
</form>


<?php include 'footer.php'; ?>

<script src="assets/js/validation.js"></script>
<script>
   
    window.onload= function (){
        
   
     var btnSubmit = document.getElementById("btn-salary");
     var salaryForm = document.getElementById("form-salary");
     var firstName=document.getElementById("first-name");
     var lastName=document.getElementById("last-name");
     var salary=document.getElementById("salary");
     var age=document.getElementById("age");
     var salaryInfo=document.getElementById("salary-info");
     var ageInfo=document.getElementById("age-info");
     var firstInfo=document.getElementById("first-name-info");
     var lastInfo=document.getElementById("last-name-info");
     var errorArray = new Array();
     //Do Validation
     document.getElementById("btn-salary").onclick= function () {
     
      if(validation.isNotEmpty(firstName.value,firstInfo)) {
        errorArray[0]=true;
      }
      else {errorArray[0]=false;}

      if(validation.isNotEmpty(lastName.value,lastInfo)){
        errorArray[1]=true;
      }
      else {errorArray[1]=false;}

      if (validation.isInteger(age.value)){
        errorArray[2]=true;
      }
      else {errorArray[2]=false;}

      if(validation.isNumber(salary.value,salaryInfo)){
        errorArray[3]=true;
      }
      else {errorArray[3]=false;}
      if ( validation.isWithinRange(age.value,16,100,ageInfo)){
        errorArray[4]=true;
      }
      else {errorArray[4]=false;}
      if (validation.isWithinRange(salary.value,1000,1000000,salaryInfo)){
        errorArray[5]=true;
      }
      else {errorArray[5]=false;}

      if (validation.checkValidation(errorArray))
      {
        salaryForm.submit();
        
      }


     
    

    
    }
       
    }
</script>
</div>
</body>
</html>