<html>
<head>
<title>Bradley's page</title>

<!-- BootStrap  and styles -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css" />
<link rel="stylesheet" href="assets/css/styles.css" />

</head>
<body>
    <div class="container">
<?php include 'header.php'; ?>

<form id="main-form" method="post" >
<div class="row">
  <div class="col-md-3 mb-3">
    <label for="first-name">First name</label>
    <input type="text" class="form-control" id="first-name" placeholder="First name"  required>
  </div>
  <div id="first-name-err" class= "invalid-feedback">
      First Name
    </div>
  <div class="col-md-3 mb-3">
    <label for="last-name">Last name</label>
    <input type="text" class="form-control" id="last-name" placeholder="Last name"  required>
  </div>
</div>
<div class="row">
  <div class="col-md-3 mb-3">
    <label for="city">City</label>
    <input type="text" class="form-control" id="city" placeholder="City" required>
    <div id="last-name-err" class= "invalid-feedback">
    Provide City
</div>
  </div>
  <div class="col-md-3 mb-3">
    <label for="state">State</label>
    <input type="text" class="form-control" id="state" placeholder="State" required>
    <div id="state-err" class= "invalid-feedback">
      
    </div>
  </div>
</div>
<div class="row">
  <div class="col-md-3 mb-3">
    <label for="job">Job</label>
    <input type="text" class="form-control" id="job" placeholder="Job Title" required>
    <div id="job-err" class= "invalid-feedback">
      
    </div>
    </div>
    <div class="col-md-3 mb-3">
    <label for="age">Age</label>
    <input type="number" class="form-control" id="age" placeholder="age" required>
    <div id="age-err" class="invalid-feedback">
      
    </div>

  </div>
</div>


<input id="register" class="btn btn-primary" type="submit" text="Submit">
</form>



<?php include 'footer.php'; ?>

<script src="assets/js/jquery-3.2.1.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<!--<script src="assets/js/validate.js"></script>-->

</div>
</body>
</html>