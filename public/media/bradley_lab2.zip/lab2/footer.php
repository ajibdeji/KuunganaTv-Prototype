<footer>

<p>
    Coypwrite &copy Bradley Blanchard 2017
</p>
</footer>